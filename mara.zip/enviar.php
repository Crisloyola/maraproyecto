<?php
if (isset($_POST['submit'])) {
    header("Location: index.html");
}
?>